<?php
// Application default settings

global $_DBv1;

global $_DBv2;

$settings = [];

// Database settings
$settings['database_v1'] = [
    'driver' => 'mysql',
    'host' => $_DBv1['db_host'],
    'unix_socket'   => $_DBv1['db_unix_socket'],
    'database' => $_DBv1['db_database'],
    'username' => $_DBv1['db_username'],
    'password' => $_DBv1['db_password'],
    'charset'  => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'strict'   => false,
    'prefix' => '',
    'options' => [
        // Turn off persistent connections
        PDO::ATTR_PERSISTENT => false,
        // Enable exceptions
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        // Emulate prepared statements
        PDO::ATTR_EMULATE_PREPARES => true,
        // Set default fetch mode to array
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ, //FETCH_ASSOC
        // Set character set
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci'
    ]
];


$settings['database_v2'] = [
    'driver' => 'mysql',
    'host' => $_DBv2['db_host'],
    'unix_socket'   => $_DBv2['db_unix_socket'],
    'database' => $_DBv2['db_database'],
    'username' => $_DBv2['db_username'],
    'password' => $_DBv2['db_password'],
    'charset'  => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'strict'   => false,
    'prefix' => '',
    'options' => [
        // Turn off persistent connections
        PDO::ATTR_PERSISTENT => false,
        // Enable exceptions
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        // Emulate prepared statements
        PDO::ATTR_EMULATE_PREPARES => true,
        // Set default fetch mode to array
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ, //FETCH_ASSOC
        // Set character set
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci'
    ]
];
// Console commands
$settings['commands'] = [
    \App\UserMigration::class,
	\App\PackageMigration::class,
	\App\ServerMigration::class,
	\App\SettingsMigration::class,
];

return $settings;
