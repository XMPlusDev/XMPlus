<?php

use Slim\App;
use Selective\BasePath\BasePathMiddleware;

return function (App $app) {
    $app->addBodyParsingMiddleware();
	
    $app->addRoutingMiddleware();
	
    $app->add(BasePathMiddleware::class);
};
