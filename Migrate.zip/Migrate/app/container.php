<?php 

use Slim\App;
use Slim\Factory\AppFactory;
use Psr\Container\ContainerInterface;
use Symfony\Component\Console\Application;
use Psr\Http\Message\ResponseFactoryInterface;
use Psr\Http\Message\ServerRequestFactoryInterface;
use Selective\BasePath\BasePathMiddleware;
use Illuminate\Database\Connection;
use Illuminate\Database\Capsule\Manager;

return [
    'settings' => function () {
        return require __DIR__ . '/settings.php';
    },
	
    App::class => function (ContainerInterface $container) {
		// create app 
        return AppFactory::createFromContainer($container);
    },
	
	 // The Slim BasePath
    BasePathMiddleware::class => function (ContainerInterface $container) {
        return new BasePathMiddleware($container->get(App::class));
    },

    // Database connection
	Connection::class => function (ContainerInterface $container) {
		$db = new Manager();
        try {
            $db->addConnection($container->get('settings')['database_v1'],'default_v1');
			$db->addConnection($container->get('settings')['database_v2']);
            $db->getConnection()->getPdo();
			$db->setAsGlobal();
			$db->bootEloquent();
        } catch (\Exception $e) {
            die('Could not connect to database: ' . $e->getMessage());
        }
        return $db;
    },
	
	// Console command
    Application::class => function (ContainerInterface $container) {
        $application = new Application();
        foreach ($container->get('settings')['commands'] as $class) {
            $application->add($container->get($class));
        }
        return $application;
    },
];