<?php

use Slim\App;
use Illuminate\Database\Connection;
use App\Factory\ContainerFactory;

require_once __DIR__ . '/../vendor/autoload.php';

// Build DI Container instance
$container = ContainerFactory::Instance();

// Initialize Database for eloquent
$container->get(Connection::class);

// Create App instance	
return $container->get(App::class);