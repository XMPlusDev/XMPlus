<?php
#XMPlus v1 Database config - Your current xmplus v1 database info
$_DBv1['db_host'] = 'localhost';
$_DBv1['db_database'] = 'v1';         
$_DBv1['db_username'] = 'root';            
$_DBv1['db_password'] = ''; 
$_DBv1['db_unix_socket'] = '';

#XMPlus v2 Database config - You new xmplus v2 databse info
$_DBv2['db_host'] = 'localhost';
$_DBv2['db_database'] = 'v2';         
$_DBv2['db_username'] = 'root';            
$_DBv2['db_password'] = ''; 
$_DBv2['db_unix_socket'] = '';


