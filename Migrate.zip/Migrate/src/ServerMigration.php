<?php

namespace App;

use App\Models\v1\Server as Serverv1;
use App\Models\v2\Server as Serverv2;
use App\Models\v2\Cloudflare;
use App\Models\v1\Zone;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

final class ServerMigration extends Command
{
    protected function configure(): void
    {
        parent::configure();

        $this->setName('migrate:server');
        $this->setDescription('server migration');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {	
		ini_set('memory_limit', '-1');
		
		$old_servers = Serverv1::all();
		
		foreach($old_servers as $new_server){
			$output->writeln('*** Migrating server '. $new_server->id.' ***');
			Serverv2::insert([
				"type" => $new_server->server,	
				"name" => $new_server->name,	
				"address" => $new_server->address,	
				"cipher" => $new_server->cipher,	
				"country" => $new_server->country,	
				"status" => $new_server->status,	
				"server_rate" => $new_server->server_rate,	
				"speedlimit" => $new_server->speedlimit,	
				"bandwidth" => $new_server->bandwidth,	
				"bandwidth_limit" => $new_server->bandwidth_limit,	
				"bandwidth_resetday" => $new_server->bandwidth_resetday,	
				"heartbeat" => $new_server->heartbeat,	
				"server_ip" => $new_server->server_ip,	
				"server_group" => 1,	
				"networkSettings" => $new_server->networkSettings,	
				"listeningip" => $new_server->listeningip,	
				"security" => $new_server->security,	
				"securitySettings" => $new_server->securitySettings,	
				"sniffing" => $new_server->sniffing,	
				"port" => $new_server->port,	
				"listeningport" => $new_server->listeningport,	
				"relayid" => $new_server->relayid,	
				"relay_type" => $new_server->relay_type,	
				"cloudflare_dns" => $new_server->cloudflare_dns,	
				"cloudflare_cdn" => $new_server->cloudflare_cdn,	
				"alive" => $new_server->alive,	
				"sort" => $new_server->sort,
				"certmode" => $new_server->certmode,
				"rule_id" => $new_server->rule_id,
				"sendthrough" => $new_server->sendthrough,
				"created_at" => $new_server->created_at,
			]);
		}
		
		$old_zones = Zone::all();
		foreach($old_zones as $new_zone){
			Cloudflare::insert([
				'api_key' => $new_zone->api_key,
				'email' => $new_zone->email,
				'status' => $new_zone->status,
				'zone_id' => $new_zone->zone_id,
				'domain' => $new_zone->domain,
				'created_at' => date("Y-m-d H:i:s", time()),
			]);
		}
		
		$output->writeln('*** Migration of servers completed ***');
		
		return Command::SUCCESS;
	}
}	