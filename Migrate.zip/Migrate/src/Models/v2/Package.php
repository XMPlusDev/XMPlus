<?php

declare(strict_types=1);

namespace App\Models\v2;

final class Package extends Model
{
    protected $connection = "default";
	
    protected $table = "package";
	
 	protected $guarded = ['id'];
}