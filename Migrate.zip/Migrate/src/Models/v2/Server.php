<?php
declare(strict_types=1);

namespace App\Models\v2;

final class Server extends Model
{
	protected $connection = 'default';
	
    protected $table = 'server';
	
    protected $casts = ['id'];
}
