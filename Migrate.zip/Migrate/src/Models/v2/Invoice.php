<?php

declare(strict_types=1);

namespace App\Models\v2;

final class Invoice extends Model
{
    protected $connection = "default";
	
    protected $table = "invoice";
	
 	protected $guarded = ['id'];

}