<?php

declare(strict_types=1);

namespace App\Models\v2;

final class Service extends Model
{
    protected $connection = "default";
	
    protected $table = "service";
	
 	protected $guarded = ['id'];

}