<?php

declare(strict_types=1);

namespace App\Models\v2;

final class User extends Model
{
    protected $connection = 'default';
	
    protected $table = 'user';
	
	protected $guarded = ['id']; 	
}