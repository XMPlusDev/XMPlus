<?php

declare(strict_types=1);

namespace App\Models\v2;

final class Cloudflare extends Model
{
    protected $connection = "default";
	
    protected $table = "cloudflare";
	
 	protected $guarded = ['id'];
}