<?php

declare(strict_types=1);

namespace App\Models\v2;

use Illuminate\Database\Eloquent\Model as EloquentModel;

abstract class Model extends EloquentModel
{
    public $timestamps = false;

    protected $guarded = [];

    public static function getNewTableName(): string
    {
        $class = static::class;
        return (new $class())->getTable();
    }
}
