<?php

declare(strict_types=1);

namespace App\Models\v2;

final class Settings extends Model
{
    protected $connection = 'default';
	
    protected $table = 'settings';
	
	protected $guarded = ['id']; 	
}