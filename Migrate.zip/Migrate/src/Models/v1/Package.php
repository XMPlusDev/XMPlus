<?php
declare(strict_types=1);

namespace App\Models\v1;

final class Package extends Model
{
    protected $connection = 'default_v1';
	
    protected $table = 'package';
	
	protected $guarded = ['id'];
}
