<?php

declare(strict_types=1);

namespace App\Models\v1;

use Illuminate\Database\Eloquent\Model as EloquentModel;

abstract class Model extends EloquentModel
{
    public $timestamps = false;

    protected $guarded = [];

    public static function getTableName(): string
    {
        $class = static::class;
        return (new $class())->getTable();
    }
}
