<?php
declare(strict_types=1);

namespace App\Models\v1;

final class User extends Model
{
	protected $connection = 'default_v1';
	
    protected $table = 'user';
	
    protected $casts = ['id'];
}
