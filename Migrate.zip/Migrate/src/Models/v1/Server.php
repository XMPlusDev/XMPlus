<?php
declare(strict_types=1);

namespace App\Models\v1;

final class Server extends Model
{
	protected $connection = 'default_v1';
	
    protected $table = 'servers';
	
    protected $casts = ['id'];
}
