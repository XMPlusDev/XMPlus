<?php
declare(strict_types=1);

namespace App\Models\v1;

final class Zone extends Model
{
    protected $connection = 'default_v1';
	
    protected $table = 'zones';
	
	protected $guarded = ['id'];
}