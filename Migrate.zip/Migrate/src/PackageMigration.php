<?php

namespace App;

use App\Models\v1\Package as Packagev1;
use App\Models\v2\Package as Packagev2;
use App\Models\v2\Invoice as Invoicev2;
use App\Models\v2\Service as Servicev2;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

final class PackageMigration extends Command
{
    protected function configure(): void
    {
        parent::configure();

        $this->setName('migrate:package');
        $this->setDescription('package migration');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {	
		ini_set('memory_limit', '-1');
		
		$old_packages = Packagev1::all();
		
		foreach($old_packages as $new_package){
			$output->writeln('*** Migrating package '. $new_package->id.' ***');
			
			$option = json_decode($new_package->price_option, true);
			
			$price_option = [
				"topup_traffic" => ["price" => (isset($option['topup']['price']) ? $option['topup']['price'] : 0.00),"status" => 'on'],
				"month" => ["price" => (isset($option['month']['price']) ? $option['month']['price'] : 0.00), "status" => 'on'],
				"quater" => ["price" => (isset($option['quater']['price']) ? $option['quater']['price'] : 0.00), "status" => 'on'],
				"semiannual" => ["price" => (isset($option['semiannual']['price']) ? $option['semiannual']['price'] : 0.00), "status" => 'on'],
				"annual" => ["price" => (isset($option['annual']['price']) ? $option['annual']['price'] : 0.00), "status" => 'on'],
			];
			
			$packageid = Packagev2::insertGetId([
				'status' => $new_package->status,
				'type' => $new_package->type,
				'name' => $new_package->name,
				'description' => '',
				'iplimit' =>  $new_package->iplimit,
				'speedlimit' =>  $new_package->speedlimit,
				'bandwidth' => $new_package->bandwidth,
				'enable_trial' => 0,
				'enable_reset' => (isset($content['enable_reset']) ? 1 : 0),
				'enable_stock' => ($new_package->stocks == 1 ? 1 : 0),
				'stock_count' => $new_package->stockcount,
				'trial_days' => 7,
				'server_group' => 1,
				'price_option' => json_encode($price_option),
				'custom_price' => (isset($option['custom']['price']) ? $option['custom']['price'] : 0.00),
				'custom_days' =>  (isset($option['custom']['expire']) ? $option['custom']['expire'] : 15),
			]);
			
			$invoices = Invoicev2::where('package_id', $new_package->id)->get();
			foreach($invoices as $invoice){
				$invoice->package_id = $packageid;
				$invoice->save();
			}
			
			$services = Servicev2::where('pid', $new_package->id)->get();
			foreach($services as $service){
				$service->pid = $packageid;
				$service->save();
			}
		}
		
		$output->writeln('*** Migration of packages completed ***');
		
		return Command::SUCCESS;
	}	
}