<?php

namespace App;

use App\Models\v1\Settings as Settingsv1;
use App\Models\v2\Settings as Settingsv2;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

final class SettingsMigration extends Command
{
    protected function configure(): void
    {
        parent::configure();

        $this->setName('migrate:settings');
        $this->setDescription('settings migration');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {	
		ini_set('memory_limit', '-1');
		
		$old_settings = Settingsv1::all();
		foreach($old_settings as $settings){
			
			if ($settings->name === 'salt') {
				Settingsv2::where('name', '=', 'appkey')
					->update(['value' => $settings->value]);
			}
			
			if ($settings->name === 'algo') {
				Settingsv2::where('name', '=', 'hash_method')
					->update(['value' => $settings->value]);
			}
			
			if ($settings->name === 'default_currency') {
				Settingsv2::where('name', '=', 'default_currency')
					->update(['value' => $settings->value]);
			}
		}
		
		$output->writeln('*** Migration of settings completed ***');
		
		return Command::SUCCESS;
	}
}