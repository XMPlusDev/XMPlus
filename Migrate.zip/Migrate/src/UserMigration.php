<?php

namespace App;

use App\Models\v1\User as Userv1;
use App\Models\v1\Order as Orderv1;
use App\Models\v2\User as Userv2;
use App\Models\v2\Invoice as Invoicev2;
use App\Models\v2\Service as Servicev2;
use App\Models\v1\Package as Packagev1;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

final class UserMigration extends Command
{
    protected function configure(): void
    {
        parent::configure();

        $this->setName('migrate:user');
        $this->setDescription('Begin migration');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {	
		ini_set('memory_limit', '-1');		
		
		$ordersv1 = Orderv1::all();
			
		foreach($ordersv1 as $order){
			$package = Packagev1::find($order->packageid);
		
			Invoicev2::insert([
				'userid' => $order->userid,
				'username' => $order->username,
				'email' => $order->email,
				'created_at' => date('Y-m-d H:i', $order->create_date),
				'inv_id' => $order->order_id,
				'callback_no' => $order->callback_no,
				'paid_amount' => $order->total_amount,
				'package_id' => $order->packageid ,
				'package_name' => ($package ? $package->name : 'v1 Migrate'),
				'package_price' => $order->package_amount,
				'qty' => 1,
				'package_type' => $order->packagetype,
				'package_expire' => $order->plan_expire,
				'discount' => ($order->discount ? $order->discount : 0.00),
				'coupon' => $order->coupon,
				'cycle' => $order->plan == 'topup' ? 'topup_traffic' : $order->plan,
				'service_id' => '',
				'user_money' => $order->user_balance,
				'remarks' => '',
				'status' =>  ($order->status == 0 ? -1 : $order->status),
				'isreseller' => 0,
				'isrenew' => $order->renew,
				'paid_date' => date('Y-m-d H:i', $order->pay_date),
			]);
		}
		
		$old_users = Userv1::all();
		
		foreach($old_users as $new_user){
			
			$output->writeln('*** Migrating user '. $new_user->id.' ***');
			
			$userid = Userv2::insertGetId([
				'email' => $new_user->email,
				'username' => $new_user->username,
				'passwd' => $new_user->passwd,
				"inviter_id" => $new_user->ref_by,
				'verify' => $new_user->verify,
				'role' => 0,
				'notification' => $new_user->notification,
				'ga' => $new_user->ga,
				'ga_status' => $new_user->ga_status,
				'created_at' => $new_user->reg_date,
				'reg_ip' => $new_user->reg_ip,
				'afflink' => $new_user->afflink,
				'telegram_token' => $new_user->tg_token,
				"telegram_id" => $new_user->telegram_id,
				"telegram_name" => $new_user->telegram_name,
				'currency' => $new_user->currency,
				'money' => $new_user->money,
				'user_group' => '',
				'lang' => 'en_US',
				'payout_completed' => $new_user->payout_completed,
				'payout_pending' => $new_user->payout_pending,
				'payout_balance' => $new_user->payout_balance,
				'old_userid' => $new_user->id
			]);

			$user = Userv2::find($userid);
			
			$order = Invoicev2::where('userid', $user->old_userid)->where('status', 1)->where("package_type", 2)->orderBy('id', 'desc')->take(1)->first();
			
			if($order){	
				$package = Packagev1::find($order->package_id);
				
				$old_order = Orderv1::find($order->package_id);
				
				Servicev2::insert([
					'type' => 2,
					'userid' => $userid,
					'email' => $new_user->email,
					'product' => $order->package_name,
					'pid' =>  $order->package_id,
					'gateway' => '---',
					'billing' => $order->cycle,
					'amount' => $order->package_price,
					'status' => (strtotime($new_user->expire_in) <= time() ? -1 : 1),
					'due_date' =>  date('Y-m-d H:i', strtotime($new_user->expire_in)),
					'paid_date' => $order->paid_date,
					'token' => $new_user->token,
					'uuid' => $new_user->uuid,
					'bandwidth' => ($package ? $package->bandwidth : ($old_order && ($old_order->bandwidth != NULL || $old_order->bandwidth != "") ? $old_order->bandwidth : $new_user->transfer_enable / (1024*1024*1024))),
					'iplimit' => $new_user->iplimit,
					'speedlimit' => $new_user->speedlimit,
					'server_group' => 1,
					'traffic' => $new_user->transfer_enable,
					'enable_reset' => ($package && $package->reset_days >= 30 ? 1 : 0),
					'invoiceid' => $order->inv_id,
					'validity' => $order->package_expire,
					'u' => $new_user->u,
					'd' => $new_user->d,
					'used' => $new_user->used,
					'total_used' => $new_user->total_data_used,
					't' => date('Y-m-d H:i', $new_user->t),
				]);
			}else{
				Servicev2::insert([
					'type' => 2,
					'userid' => $userid,
					'email' => $new_user->email,
					'product' => 'v1 Migrate',
					'pid' =>  -1,
					'gateway' => '---',
					'billing' => '',
					'amount' => '0.00',
					'status' => (strtotime($new_user->expire_in) <= time() ? -1 : 1),
					'due_date' =>  date('Y-m-d H:i', strtotime($new_user->expire_in)),
					'paid_date' => '---',
					'token' => $new_user->token,
					'uuid' => $new_user->uuid,
					'bandwidth' => $new_user->transfer_enable / (1024*1024*1024),
					'iplimit' => $new_user->iplimit,
					'speedlimit' => $new_user->speedlimit,
					'server_group' => 1,
					'traffic' => $new_user->transfer_enable,
					'enable_reset' => 0,
					'invoiceid' => '---',
					'validity' => 0,
					'u' => $new_user->u,
					'd' => $new_user->d,
					'used' => $new_user->used,
					'total_used' => $new_user->total_data_used,
					't' => date('Y-m-d H:i', $new_user->t),
				]);
			}
			
			$orders = Invoicev2::where('userid', $user->old_userid)->get();
			
			foreach($orders as $order){
				$order->userid = $user->id;
				$order->save();
			}
			
		}	
		
		$output->writeln('*** Migration of users completed ***');
		
		return Command::SUCCESS;
	}
}	